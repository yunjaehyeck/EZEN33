from calc_2 import CalUI

if __name__ == '__main__':
    CalUI.main()






