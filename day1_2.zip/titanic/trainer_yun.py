#
# 컨테이너를 만드는 파일
#

# 판다스 : 문자열   ,  넌파이 : 숫자   ---> 텍스트 분석에 쓰이는 데이터 형태.
import pandas as pd  # from 은 생략 : 내장함수(객체) 이므로 생략.
import matplotlib.pyplot as plt # 파이썬과 텐소 중에소 파이썬용으로 가지고 옴.
import seaborn as sns  # 여러 그래프를 중첩해서 보여주는 객체.


ctx = 'C:/Users/ezen/PycharmProjects/day1_2/titanic/data/' # 가져올 데이터 위치
train = pd.read_csv(ctx+'train.csv') # 판다스를 이용해 파일 내용을 텍스트 형태로 얻어 옴.
test = pd.read_csv(ctx+'test.csv')

# print(train.head()) # 파일내용 출력(확인용) --  head()함수는 상위 5개 파일만을 선택 함.
#df = pd.DataFrame(train)
#print(df.columns)

"""
['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp', 'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked']
"""


"""
[Variable]                [Definition]    [Key]
PassengerId
Survived
Pclass
Name
Sex
Age
SibSp
Parch
Ticket
Fare
Cabin
Embarked

survival 생존여부         Survival        0 = No, 1 = Yes
pclass   승선권 클래스    Ticket class    1 = 1st, 2 = 2nd, 3 = 3rd
sex      성별             Sex    
Age      나이             Age in years    
sibsp    동반한 형제자매, 배우자수   # of siblings / spouses aboard the Titanic    
parch    동반한 부모, 자식 수   # of parents / children aboard the Titanic    
ticket   티켄 번호        Ticket number    
fare     티켓 요금        Passenger fare    
cabin    객실번호         Cabin number    
embarked 승선한 항구명    Port of Embarkation    
C = Cherbourg 쉐부로, Q = Queenstown 퀜스타운, S = Southampton 사우스햄톤

"""
"""
# 생존률

f, ax = plt.subplots(1, 2, figsize=(18, 8))
train['Survived'].value_counts().plot.pie(explode=[0,0.1],autopct="%1.1f%%", ax=ax[0], shadow=True)
ax[0].set_title('Survived')
ax[0].set_ylabel('')

sns.countplot('Survived', data=train, ax=ax[1])
ax[1].set_title('Survived')
plt.show()  # 생존률 38.4% 사망률 61.6%
"""

"""
데이터는 훈련데이터(train.csv) , 목적데이터(test.csv) 두가지로 제공 됩니다.
목적데이터는 위 항목에서는 Survived 정보가 빠져있습니다.
그것은 정답이기 때문입니다.
"""

# 성별
"""
f, ax = plt.subplots(1, 2, figsize=(18, 8))
train['Survived'][train["Sex"] == 'male'].value_counts().plot.pie(explode=[0,0.1],autopct="%1.1f%%", ax=ax[0], shadow=True)
train['Survived'][train["Sex"] == 'female'].value_counts().plot.pie(explode=[0,0.1],autopct="%1.1f%%", ax=ax[1], shadow=True)
ax[0].set_title('Survived(Male)')
ax[1].set_title('Survived(Female)')

plt.show()  # 남성 생존률 18.9%  사망률 81.1%   # 여성 생존률 74.2% 사망률 25.8%
"""

#승선권 Pclass
"""
f, ax = plt.subplots(1, 2, figsize=(18, 8))
train['Survived'][train["Sex"] == 'male'].value_counts().plot.pie(explode=[0,0.1],autopct="%1.1f%%", ax=ax[0], shadow=True)
ax[0].set_title('Survived(Male)')
ax[1].set_title('Survived(Female)')

df_1 = [train['Sex'],train['Survived']]
df_2 = train['Pclass']
df = pd.crosstab(df_1, df_2, margins=True)

#print(df.head())
"""
"""
Pclass             1    2    3  All
Sex    Survived                    
female 0           3    6   72   81
       1          91   70   72  233
male   0          77   91  300  468
       1          45   17   47  109
All              216  184  491  891
"""

"""
f, ax = plt.subplots(2, 2, figsize=(20, 15))
sns.countplot('Embarked', data=train, ax=ax[0,0])
ax[0,0].set_title('No. of Passengers Boarded')

sns.countplot('Embarked', hue='Sex', data=train, ax=ax[0,1])
ax[0,1].set_title('Male - Female for Embarked')

# 배를 탄 항구 "Embarked"
sns.countplot('Embarked', hue='Survived', data=train, ax=ax[1,0])
ax[1,0].set_title('Pclass vs Survived')

sns.countplot('Pclass', data=train, ax=ax[1,1])
ax[1,1].set_title('Embarked vs PClass')

plt.show()
"""
"""
위 데이터를 보면 절반 이상의 승객이 ‘Southampton’에서 배를 탔으며, 여기에서 탑승한 승객의 70% 가량이 남성이었습니다. 현재까지 검토한 내용으로는 남성의 사망률이 여성보다 훨씬 높았기에 자연스럽게 ‘Southampton’에서 탑승한 승객의 사망률이 높게 나왔습니다.
또한 ‘Cherbourg’에서 탑승한 승객들은 1등 객실 승객의 비중 및 생존률이 높은 것으로 보아서 이 동네는 부자동네라는 것을 예상할 수 있습니다.
"""

# 결측치 제거

#train.info()
"""
PassengerId    891 non-null int64
Survived       891 non-null int64
Pclass         891 non-null int64
Name           891 non-null object
Sex            891 non-null object
Age            714 non-null float64
SibSp          891 non-null int64
Parch          891 non-null int64
Ticket         891 non-null object
Fare           891 non-null float64
Cabin          204 non-null object
Embarked       889 non-null object
dtypes: float64(2), int64(5), object(5)
"""

# print(train.isnull().sum())

"""
PassengerId      0
Survived         0
Pclass           0
Name             0
Sex              0
Age            177
SibSp            0
Parch            0
Ticket           0
Fare             0
Cabin          687
Embarked         2
"""
"""
def var_chart(feature):
    survived = train[train['Survived'] == 1][feature].value_counts()  #생존자들.
    dead = train[train['Survived'] == 0][feature].value_counts()
    df = pd.DataFrame([survived, dead])
    df.index = ['survived', 'dead']
    df.plot(kind='bar', stacked=True, figsize=(10,5))
    plt.show()

var_chart('Sex')
var_chart('Pclass')
var_chart('SibSp')
var_chart('Parch')
var_chart('Embarked')
"""



