# ********************
# 성적표
# ********************

name = input("이름 : ")
kor = int(input("국어 : "))
mat = int(input("수학 : "))
eng = int(input("영어 : "))

tot = kor + mat + eng
avg = tot / 3

print("총점 : ", tot)
print("평균 : ", avg)



